#!/bin/bash

#/***************************************************************************
#*                                                                          *
#*  OpenNI 2.0                                                              *
#*  Copyright (C) 2012 PrimeSense Ltd.                                      *
#*                                                                          *
#*  This file is part of OpenNI2 installation.                              *
#*                                                                          *
#*  OpenNI is free software: you can redistribute it and/or modify          *
#*  it under the terms of the GNU Lesser General Public License as published*
#*  by the Free Software Foundation, either version 3 of the License, or    *
#*  (at your option) any later version.                                     *
#*                                                                          *
#*  OpenNI is distributed in the hope that it will be useful,               *
#*  but WITHOUT ANY WARRANTY; without even the implied warranty of          *
#*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the            *
#*  GNU Lesser General Public License for more details.                     *
#*                                                                          *
#*  You should have received a copy of the GNU Lesser General Public License*
#*  along with OpenNI. If not, see <http://www.gnu.org/licenses/>.          *
#*                                                                          *
#***************************************************************************/
#

# Check if user is root/running with sudo
if [ `whoami` != root ]; then
    echo Please run this script with sudo
    exit
fi

ORIG_PATH=`pwd`
cd `dirname $0`
SCRIPT_PATH=`pwd`
cd $ORIG_PATH

usage="
Usage: $0 [OPTIONS]
Installs OpenNI to current machine.

-i,--install
    Installs OpenNI (default mode)
-u,--uninstall
    Uninstalls OpenNI.
-h,--help
    Shows this help screen.
"
# parse command line
while [ "$1" ]; do
    case $1 in
    -i|--install)
        install=yes
        ;;
    -u|--uninstall)
        uninstall=yes
        ;;
    -h|--help)
        echo "$usage"
        exit 0
        ;;
    *)
        echo "Unrecognized option $1"
        exit 1
    esac
    shift
done
# default mode is install
if [ ! "$install" = yes ] && [ ! "$uninstall" = yes ]; then
    install=yes
fi

# validity check
if [ "$install" = yes ] && [ "$uninstall" = yes ]; then
    echo "-i and -u flags cannot be used together!"
    exit 1
fi

# Declare Suffix Strings
Suffix=Terabee
suffix=$(echo $Suffix | tr '[:upper:]' '[:lower:]')
SUFFIX=$(echo $suffix | tr '[:lower:]' '[:upper:]')

# Make Dir
INSTALL_USR=$rootfs/usr/etc/$SUFFIX
INSTALL_USR_LIB=$INSTALL_USR/lib
mkdir -p $INSTALL_USR_LIB

INSTALL_LIB=$rootfs/usr/lib
USR_LOCAL=$rootfs/usr/local
CV_VER_REQUIRED=3.4
CV_DIR=cv$CV_VER_REQUIRED

if [ "$install" = yes ]; then
    # detect Linux OS distribution
    printf "Detect OS distribution version and create links\n"
    DIST_ID=`lsb_release -i -s`
    DIST_RE=`lsb_release -r -s`
    DIST_CO=`lsb_release -c -s`
    if [ "$DIST_ID" = "Ubuntu" ]; then
        if echo "$DIST_RE" | grep -q "14.*"; then
            DIST_REL_NAME=14.04
        else
            #for any Ubuntu version greater than 16.04
            DIST_REL_NAME=16.04
        fi
        printf "It's $DIST_ID $DIST_RE\n\n"
    elif [ "$DIST_ID" = "LinuxMint" ]; then
        if [ "$DIST_RE" = "17" ]; then
            DIST_REL_NAME=14.04
        elif echo "$DIST_RE" | grep -q "17.*"; then
            DIST_REL_NAME=14.04
        else
            #for any Mint version greater than 18
            DIST_REL_NAME=16.04
        fi
        printf "It's $DIST_ID $DIST_RE\n\n"
    elif [ "$DIST_ID" = "elementary" ]; then
        if [ "$DIST_RE" = "0.3" ]; then
            DIST_REL_NAME=14.04
        elif echo "$DIST_RE" | grep -q "0.3.*"; then
            DIST_REL_NAME=14.04
        else
            #for any elementary OS greater than 0.4 Loki
            DIST_REL_NAME=16.04
        fi
        printf "It's $DIST_ID $DIST_RE\n\n"
    elif [ "$DIST_ID" = "Debian" ] || [ "$DIST_ID" = "Raspbian" ]; then
        if [ "$DIST_CO" = "jessie" ]; then
            DIST_REL_NAME=14.04
        else
            #for any Debian version greater than Stretch
        DIST_REL_NAME=16.04
        fi
    else
        #Let Ubuntu 16.04 as default distribution for install
        printf "Unrecognized distribution! Install default library (for Ubutnu 16.04)\n\n"
        DIST_REL_NAME=16.04
    fi
    # Ubuntu 14.04 is not supported since SDK v1.6.0.0
    if [ "$DIST_REL_NAME" = "14.04" ]; then
        printf "Sorry! Ubuntu 14.04 is not supported since SDK v1.6.0.0. Please contact vendor support.\n"
        exit 0
    fi
    # Install libopenni2-dev and openni2-utils
    ni2_pkgs="libopenni2-dev openni2-utils"
    apt-get update
    #apt-get install software-properties-common
    for p in $ni2_pkgs
    do
        if [ ! -z "$(dpkg -l | grep $p)" ]; then
            printf "found package $p. Okay!\n"
        else
            printf "installing package $p...\n"
            apt-get install -yq $p
    fi
    done

    #create lib links
    CONF_FILELIST=`ls $SCRIPT_PATH/$SUFFIX/$SUFFIX/config/*.json`
    LIBS_FILELIST=`ls $SCRIPT_PATH/$SUFFIX/$SUFFIX/lib/lib*.so*`

    if [ "`uname -s`" != "Darwin" ]; then
        # Install UDEV rules for USB device
        printf "copying video udev rules..."
        cp ${SCRIPT_PATH}/99-$SUFFIX-video.rules /etc/udev/rules.d/99-$SUFFIX-video.rules
        chmod a+r /etc/udev/rules.d/99-$SUFFIX-video.rules
        printf "OK..\n"

        # SDK libs: libdevicesensor
        printf "copying SDK libraries..."
        for filename in $LIBS_FILELIST; do
            if [ -f $filename ]; then
                cp -pf $filename $INSTALL_USR_LIB/
                cp -pf $filename $INSTALL_LIB/
            else
                # remember to remove previous installed libs from system
                [ -f $INSTALL_USR_LIB/`basename $filename` ] && rm -f $INSTALL_USR_LIB/`basename $filename`
                [ -f $INSTALL_LIB/`basename $filename` ] && rm -f $INSTALL_LIB/`basename $filename`
            fi
        done

        # special copy for RPi3 ARM: check and re-test .so link
        if [ -d $INSTALL_LIB/OpenNI2/Drivers ]; then
            #install driver to /usr/lib/OpenNI2/Drivers if found
            [ -e $INSTALL_LIB/OpenNI2/Drivers/libmodule-${suffix}2.so ] && rm -f $INSTALL_LIB/OpenNI2/Drivers/libmodule-${suffix}2.so
            cp -pf $SCRIPT_PATH/Tools/OpenNI2/Drivers/libmodule-${suffix}2.so $INSTALL_LIB/OpenNI2/Drivers/libmodule-${suffix}2.so.0
            cd $INSTALL_LIB/OpenNI2/Drivers
            ln -sf libmodule-${suffix}2.so.0 libmodule-${suffix}2.so
            cd - > /dev/null

            #install OpenNI.ini to /usr/lib/
            [ -f $SCRIPT_PATH/Tools/OpenNI.ini ] && cp $SCRIPT_PATH/Tools/OpenNI.ini $INSTALL_LIB/
        fi
        printf "OK\n"

        printf "detecting OpenCV library...\n"
        # install opencv-3.1.0 libs and include headers
        # handle cv dependent libraries
        #ADDTIONALS="libtbb2 libtbb-dev" <-- optional for cv3.4.1 lib
        cv_depends="libgtk2.0-dev libjpeg8 libpng12-0"
        apt-get update
        #apt-get install libgtk2.0-dev libavcodec-dev libavformat-dev libjpeg.dev libtiff4.dev libswscale-dev libjasper-dev
        for p in $cv_depends
        do
            if [ ! -z "$(dpkg -l | grep $p)" ]; then
                printf "found package $p. Okay!\n"
            else
                printf "installing package $p...\n"
                apt-get install -yq $p
            fi
        done

        [ ! -f /usr/bin/find ] && sudo apt-get install -yq pkg-config findutils
        # default version 0.0.0 means Not Found
        CV_PKG_VER="0.0.0"
        [ ! `pkg-config --exists opencv` ] && CV_PKG_VER=`pkg-config --modversion opencv`
        CV_CUR_VER=${CV_PKG_VER:0:3}
        CV_INSTALL_PREBUILT=YES
        FIND_CVSO=`find /usr/local/lib -name libopencv_world.so.$CV_VER_REQUIRED`
        if [ "$CV_CUR_VER" != "$CV_VER_REQUIRED" ] || [ "$FIND_CVSO" == "" ]; then
            if [ "$CV_INSTALL_PREBUILT" == "NO" ]; then
                echo ""
                echo "# WARNING! OpenCV libopencv_world.so.$CV_VER_REQUIRED is required!"
                echo "#"
                echo "# Please check OpenCV Installation Guide for more support"
                echo "# https://docs.opencv.org/3.4.1/d7/d9f/tutorial_linux_install.html"
                echo "#"
                echo ""
            elif [ "$CV_INSTALL_PREBUILT" == "YES" ]; then
                printf "installing prebuilt OpenCV libs..."
                # install prebuilt opencv libs
        cp -pr $SCRIPT_PATH/$CV_DIR/lib $USR_LOCAL/
        cp -pr $SCRIPT_PATH/$CV_DIR/include $USR_LOCAL/
        ldconfig
        printf "OK\n"
            fi
        else
            echo ""
            echo "# OpenCV libopencv_world.so.$CV_VER_REQUIRED is found!"
            echo "#   libs: "`pkg-config --libs opencv`
            echo "# cflags: "`pkg-config --cflags opencv`
            echo ""
        fi
        #copy config file
        printf "copying SDK config..."
        cp -pf $CONF_FILELIST $INSTALL_USR_LIB
        printf "OK\n"
    fi

    OUT_FILE="$SCRIPT_PATH/OpenNIDevEnvironment"

    echo "export OPENNI2_INCLUDE=$SCRIPT_PATH/Include" > $OUT_FILE
    echo "export OPENNI2_REDIST=$SCRIPT_PATH/Redist" >> $OUT_FILE
    chmod a+r $OUT_FILE

    printf "DONE...\n"
fi

if [ "$uninstall" = yes ]; then
    # OpenNI2 modules
    printf "Removing SDK libraries..."
    for filename in $LIBS_FILELIST; do
        [ -f $INSTALL_USR_LIB/`basename $filename` ] && rm -f $INSTALL_USR_LIB/`basename $filename`
        [ -f $INSTALL_LIB/`basename $filename` ] && rm -f $INSTALL_LIB/`basename $filename`
    done
    #special remove for RPi3 ARM
    [ -e $INSTALL_LIB/OpenNI2/Drivers/libmodule-${suffix}2.so ] && rm -f $INSTALL_LIB/OpenNI2/Drivers/libmodule-${suffix}2.so
    [ -e $INSTALL_LIB/OpenNI2/Drivers/libmodule-${suffix}2.so.0 ] && rm -f $INSTALL_LIB/OpenNI2/Drivers/libmodule-${suffix}2.so.0
    [ -e $INSTALL_LIB/OpenNI.ini ] && rm -f $INSTALL_LIB/OpenNI.ini
    #rm -f $USR_LOCAL/lib/libopencv_*.so.3.4.1
    #rm -f $USR_LOCAL/lib/libopencv_*.so.3.4
    #rm -f $USR_LOCAL/lib/libopencv_*.so
    #rm -f $USR_LOCAL/lib/pkgconfig/opencv.pc
    #rm -rf $USR_LOCAL/include/opencv
    #rm -rf $USR_LOCAL/include/opencv2
    printf "OK\n"

    printf "Removing SDK config..."
    for configname in $CONF_FILELIST; do
        rm -f $INSTALL_USR_LIB/`basename $configname`
    done

    printf "OK\n"

    rm -rf $INSTALL_USR
    rm -f /etc/udev/rules.d/99-$SUFFIX-video.rules

    printf "DONE.....\n"
fi

