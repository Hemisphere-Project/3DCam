#!/bin/bash
#
# Refer to URL https://docs.opencv.org/3.4.1/d7/d9f/tutorial_linux_install.html
#
sudo apt-get update
# [compiler]
sudo apt-get install -yq build-essential
# [required]
sudo apt-get install -yq cmake git libgtk2.0-dev pkg-config
sudo apt-get isntall -yq libavcodec-dev libavformat-dev libswscale-dev
# [optional]
sudo apt-get install -yq python-dev python-numpy python-pip libtbb2 libtbb-dev
sudo apt-get install -yq libjpeg-dev libpng-dev
#sudo apt-get install -yq libtiff-dev libjasper-dev libdc1394-22-dev

CV_VER=3.4.1
CV_NAME=opencv$CV_VER

wget -O 3.4.1.zip https://github.com/opencv/opencv/archive/3.4.1.zip --no-check-certificate

unzip -uoq 3.4.1.zip
cd opencv-3.4.1

mkdir build
cd build

cmake \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX=/usr/local \
  -DBUILD_opencv_world=ON \
  -DBUILD_PERF_TESTS=OFF \
  -DBUILD_TESTS=OFF \
  -DBUILD_DOCS=OFF \
  -DBUILD_EXAMPLES=OFF \
  ..

make -j4

echo "Done!"
echo ""
echo "Run 'sudo make install' for installation"
echo ""
echo "Run 'sudo ldconfig' to update library path"
echo ""
